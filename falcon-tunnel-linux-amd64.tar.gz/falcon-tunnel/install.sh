#!/usr/bin/env bash
#
# FalconTunnel server — one-shot installer / configurator.
#
# Installs the binary, writes a systemd service, enables IP forwarding, and starts
# the tunnel. Run as root on the Linux VPS. Everything is configurable by flag or
# interactive prompt.
#
#   sudo ./install.sh                       # interactive
#   sudo ./install.sh --host 84.32.50.8 --admin-pass 's3cret' -y   # non-interactive
#
set -euo pipefail

# ---- defaults -------------------------------------------------------------
PORT=1194
ADMIN_PORT=8088
ADMIN_USER=admin
ADMIN_PASS=""
ADMIN_BIND="0.0.0.0"        # set 127.0.0.1 to keep the panel local-only
HOST=""
TUN=falcon0
SUBNET=10.9.0.1
NO_ADMIN=0
ASSUME_YES=0

PREFIX=/usr/local/bin
WORKDIR=/etc/falcon-tunnel
SERVICE=falcon-tunnel
BINSRC=""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---- helpers --------------------------------------------------------------
c()   { printf '\033[%sm%s\033[0m' "$1" "$2"; }
info(){ echo "$(c '1;36' '==>') $*"; }
warn(){ echo "$(c '1;33' 'warning:') $*" >&2; }
die() { echo "$(c '1;31' 'error:') $*" >&2; exit 1; }

usage() {
  cat <<EOF
FalconTunnel installer

Usage: sudo ./install.sh [options]

  --host <ip/host>     Public address advertised in the import URL (auto-detected if omitted)
  --port <n>           UDP listen/advertise port            (default: $PORT)
  --tun <name>         TUN interface name                   (default: $TUN)
  --subnet <ip>        Server tunnel IP (clients get .2+)    (default: $SUBNET)
  --admin-user <u>     Admin panel username                 (default: $ADMIN_USER)
  --admin-pass <p>     Admin panel password                 (generated if omitted)
  --admin-port <n>     Admin panel HTTP port                (default: $ADMIN_PORT)
  --admin-bind <ip>    Admin panel bind address             (default: $ADMIN_BIND)
  --no-admin           Disable the admin panel entirely
  --binary <path>      Use this prebuilt linux binary
  -y, --yes            Non-interactive: accept all defaults
  -h, --help           Show this help

Examples:
  sudo ./install.sh
  sudo ./install.sh --host 84.32.50.8 --admin-pass 'hunter2' -y
EOF
}

# ---- parse args -----------------------------------------------------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --host)       HOST="$2"; shift 2;;
    --port)       PORT="$2"; shift 2;;
    --tun)        TUN="$2"; shift 2;;
    --subnet)     SUBNET="$2"; shift 2;;
    --admin-user) ADMIN_USER="$2"; shift 2;;
    --admin-pass) ADMIN_PASS="$2"; shift 2;;
    --admin-port) ADMIN_PORT="$2"; shift 2;;
    --admin-bind) ADMIN_BIND="$2"; shift 2;;
    --no-admin)   NO_ADMIN=1; shift;;
    --binary)     BINSRC="$2"; shift 2;;
    -y|--yes)     ASSUME_YES=1; shift;;
    -h|--help)    usage; exit 0;;
    *)            die "unknown option: $1 (see --help)";;
  esac
done

[[ $EUID -eq 0 ]] || die "must run as root (use sudo)."

# ---- locate the binary ----------------------------------------------------
if [[ -z "$BINSRC" ]]; then
  for cand in "$SCRIPT_DIR/falcon-server-linux" "$SCRIPT_DIR/dist/falcon-server-linux" "$SCRIPT_DIR/falcon-server"; do
    [[ -f "$cand" ]] && { BINSRC="$cand"; break; }
  done
fi
if [[ -z "$BINSRC" ]]; then
  if command -v go >/dev/null 2>&1 && [[ -f "$SCRIPT_DIR/go.mod" ]]; then
    info "no prebuilt binary found; building from source with go..."
    ( cd "$SCRIPT_DIR" && CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -trimpath -ldflags "-s -w" -o /tmp/falcon-server-linux . )
    BINSRC=/tmp/falcon-server-linux
  else
    die "no falcon-server-linux binary next to this script and 'go' not available to build one."
  fi
fi
[[ -f "$BINSRC" ]] || die "binary not found: $BINSRC"

# ---- auto-detect public IP ------------------------------------------------
detect_ip() {
  local ip=""
  ip="$(curl -fsS --max-time 4 https://api.ipify.org 2>/dev/null || true)"
  [[ -z "$ip" ]] && ip="$(curl -fsS --max-time 4 https://ifconfig.me 2>/dev/null || true)"
  [[ -z "$ip" ]] && ip="$(ip -o route get 1.1.1.1 2>/dev/null | sed -n 's/.*src \([0-9.]*\).*/\1/p')"
  echo "$ip"
}

# ---- interactive prompts --------------------------------------------------
ask() { # ask <var> <prompt> <default>
  local __v="$1" __p="$2" __d="$3" __in=""
  if [[ $ASSUME_YES -eq 1 ]]; then printf -v "$__v" '%s' "$__d"; return; fi
  read -r -p "$__p [$__d]: " __in || true
  printf -v "$__v" '%s' "${__in:-$__d}"
}

DEFAULT_HOST="${HOST:-$(detect_ip)}"
[[ -z "$DEFAULT_HOST" ]] && DEFAULT_HOST="0.0.0.0"

echo
info "FalconTunnel server setup"
ask HOST       "Public host/IP clients connect to" "$DEFAULT_HOST"
ask PORT       "UDP port"                           "$PORT"
ask TUN        "TUN interface name"                 "$TUN"
ask SUBNET     "Server tunnel IP"                   "$SUBNET"

if [[ $NO_ADMIN -eq 0 ]]; then
  if [[ $ASSUME_YES -eq 0 ]]; then
    read -r -p "Enable admin web panel? [Y/n]: " _a || true
    [[ "${_a:-Y}" =~ ^[Nn] ]] && NO_ADMIN=1
  fi
fi
if [[ $NO_ADMIN -eq 0 ]]; then
  ask ADMIN_USER "Admin username"   "$ADMIN_USER"
  ask ADMIN_PORT "Admin panel port" "$ADMIN_PORT"
  ask ADMIN_BIND "Admin bind addr"  "$ADMIN_BIND"
  if [[ -z "$ADMIN_PASS" ]]; then
    if [[ $ASSUME_YES -eq 1 ]]; then
      ADMIN_PASS="$(head -c 12 /dev/urandom | base64 | tr -d '/+=' | cut -c1-16)"
      info "generated admin password: $(c '1;32' "$ADMIN_PASS")"
    else
      read -r -s -p "Admin password (blank = generate): " ADMIN_PASS; echo
      if [[ -z "$ADMIN_PASS" ]]; then
        ADMIN_PASS="$(head -c 12 /dev/urandom | base64 | tr -d '/+=' | cut -c1-16)"
        info "generated admin password: $(c '1;32' "$ADMIN_PASS")"
      fi
    fi
  fi
fi

[[ "$HOST" == "0.0.0.0" || -z "$HOST" ]] && warn "host is $HOST — the import URL won't be reachable from phones. Re-run with --host <public-ip>."

# ---- install --------------------------------------------------------------
info "installing binary -> $PREFIX/falcon-server"
install -m 0755 "$BINSRC" "$PREFIX/falcon-server"
mkdir -p "$WORKDIR"
chmod 0700 "$WORKDIR"

# persistent IP forwarding (v4 + v6, since inner traffic is IPv6)
info "enabling IP forwarding"
cat >/etc/sysctl.d/99-falcon-tunnel.conf <<EOF
net.ipv4.ip_forward=1
net.ipv6.conf.all.forwarding=1
EOF
sysctl -p /etc/sysctl.d/99-falcon-tunnel.conf >/dev/null 2>&1 || true

# ---- build the ExecStart command -----------------------------------------
EXEC="$PREFIX/falcon-server -host $HOST -listen :$PORT -port $PORT -tun $TUN -subnet $SUBNET"
if [[ $NO_ADMIN -eq 0 ]]; then
  EXEC="$EXEC -admin-listen $ADMIN_BIND:$ADMIN_PORT -admin-user $ADMIN_USER -admin-pass $ADMIN_PASS"
fi

info "writing systemd unit -> /etc/systemd/system/$SERVICE.service"
cat >/etc/systemd/system/$SERVICE.service <<EOF
[Unit]
Description=FalconTunnel VPN server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=$WORKDIR
ExecStart=$EXEC
Restart=on-failure
RestartSec=3
AmbientCapabilities=CAP_NET_ADMIN CAP_NET_RAW
LimitNOFILE=65535

[Install]
WantedBy=multi-user.target
EOF
chmod 0600 /etc/systemd/system/$SERVICE.service   # ExecStart contains the admin password

systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null 2>&1 || true
info "starting $SERVICE"
systemctl restart "$SERVICE"
sleep 1

# ---- summary --------------------------------------------------------------
echo
if systemctl is-active --quiet "$SERVICE"; then
  info "$(c '1;32' 'FalconTunnel is running.')"
else
  warn "service did not come up; check: journalctl -u $SERVICE -e"
fi

IMPORT_URL="$(journalctl -u "$SERVICE" -n 40 --no-pager 2>/dev/null | grep -o 'falcontunnel://import/[A-Za-z0-9+/=_-]*' | tail -1 || true)"

echo
echo "  Service    : systemctl status $SERVICE"
echo "  Logs       : journalctl -u $SERVICE -f"
echo "  Config dir : $WORKDIR   (server_key.b64 / client_key.b64 live here)"
if [[ $NO_ADMIN -eq 0 ]]; then
  echo "  Admin panel: http://$HOST:$ADMIN_PORT/   (user: $ADMIN_USER  pass: $ADMIN_PASS)"
fi
echo
if [[ -n "$IMPORT_URL" ]]; then
  echo "  Import URL (paste into the FalconTunnel app):"
  echo "    $(c '1;36' "$IMPORT_URL")"
else
  echo "  Import URL: run 'journalctl -u $SERVICE | grep import' to copy it."
fi
echo
info "done."
