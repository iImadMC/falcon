# FalconTunnel — Protocol Crack & Server Construction

This document explains (1) how the FalconTunnel key‑derivation was reverse‑engineered
from the real Android client, and (2) how `falcon-server` is built to be byte‑for‑byte
compatible with the app so it can act as a working VPN endpoint.

> **Scope / authorization.** This is a self‑authored, self‑hosted VPN endpoint. We hold
> **both** static private keys (server + client), so all handshake secrets are known to us
> by construction. Nothing here breaks a third party's confidentiality; it reproduces our
> own client's protocol so an open server can terminate the tunnel.

---

## 1. The decisive advantage: we hold both static keys

The import URL (`falcontunnel://import/...`) carries the **client** static private key, and
we generate the **server** static private key ourselves. Therefore every Diffie–Hellman
value in the handshake is computable offline:

| Secret | Definition | Known because |
|--------|------------|----------------|
| `ss`   | `DH(clientStatic, serverStatic)` | we hold both static privs |
| `ee`   | `DH(clientEph,    serverEph)`     | both ephemerals observed / generated |
| `es`   | `DH(clientEph,    serverStatic)`  | server static priv known |
| `se`   | `DH(clientStatic, serverEph)`     | client static priv known |

This turned an online protocol attack into an **offline known‑plaintext calibration**: dump
the four DH secrets plus real ciphertext, then search for the exact KDF that reproduces the
captured packets.

---

## 2. Wire protocol

All traffic is UDP (default port `1194`). The first byte is a packet‑type tag.

| Tag    | Name         | Layout |
|--------|--------------|--------|
| `0x00` | Decoy (STUN) | traffic‑shaping noise; ignored |
| `0x01` | ClientHello  | `0x01 ‖ clientStaticPub(32) ‖ clientEphPub(32)` → **65 bytes**, cleartext |
| `0x02` | ServerHello  | `0x02 ‖ serverStaticPub(32) ‖ serverEphPub(32) ‖ assignedIP(4) ‖ mtu(2 BE) ‖ dnsCount(1) ‖ dns[4]…` |
| `0x03` | Data         | `0x03 ‖ seq(4 BE) ‖ ciphertext ‖ tag(16)` (ChaCha20‑Poly1305) |
| `0x04` | Keepalive    | token echo |
| `0x80` | Decoy (RTP)  | traffic‑shaping noise; ignored |

Notes:

- Static **and** ephemeral public keys are sent **in the clear** in the hellos. The app does
  *not* Noise‑encrypt the initiator static, which is what ultimately makes the KDF derivable.
- The handshake is X25519 (curve25519). AEAD is ChaCha20‑Poly1305.
- **Inner (tunnelled) traffic is IPv6.** The first packets the client sends are ICMPv6:
  seq 0 is an MLD/Multicast‑Listener message, seq 1 is a Router Solicitation (ICMPv6 type
  `0x85`). This detail matters for NAT (see §6).

---

## 3. The crack

### 3.1 Data captured (`crack_dump.json`)

The server dumps, once per session, the four DH secrets, all four handshake public keys, and
the buffered `0x03` ciphertext packets (seq 0 = 88‑byte body, seq 1 = 64‑byte body — each body
is `ciphertext ‖ 16‑byte tag`).

### 3.2 What failed (and why it mattered)

A large brute force (~9M combinations) all failed. The dead ends were informative:

- **Every ordered subset of the 4 DH secrets as HKDF IKM** — with/without a transcript hash
  prepended/appended, ~40 salts, 6 labels, 8 AAD layouts, 6 nonce layouts, plus a
  keystream‑only oracle. → nothing.
- **Noise‑style iterative chaining** (`ck = MixKey(ck, dh)` for candidate protocol names and
  mix orders) followed by an empty‑IKM Split. → nothing.
- **Hybrid**: Noise chaining **then** labelled `HKDF‑Expand`. → nothing.

Two hidden assumptions were wrong, and they were exactly why the searches couldn't match:

1. The inner packets are **IPv6**, so the original `looksLikeIPv4` plaintext oracle could
   never fire. (Later searches switched to the Poly1305 tag as the oracle, which is direction‑
   and layout‑agnostic.)
2. The key does **not** mix all four DH secrets. Only `ss` is secret input; the ephemeral
   **public** keys are used as salt. No "subset of DH secrets" search could express that.

### 3.3 Disassembly — the structural clue

Disassembling `libfalcon_android.so` around the two label references
(`falcon-c2s` @ `0x1b4c3`, `falcon-s2c` @ `0x1b4cd`; expand call site `0x5f326`, HKDF‑Expand
at `0x87990`) revealed the Extract HMAC:

- Clear HMAC shape: key XORed with a broadcast `0x36…` (ipad) then `0x5c…` (opad), two
  SHA‑256 compressions (`0xa53d0`, containing the `0x428a2f98` round constant).
- **The HMAC key is 64 bytes** — `[rsp+0x5f0]`(32) concatenated with a session‑struct field
  `[rbp+0xb60]`(32) — not a 32‑byte salt zero‑padded to the block size.
- **The HMAC message (IKM) is 32 bytes.**

So the construction is `PRK = HMAC‑SHA256(key = A‖B (64 bytes), msg = C (32 bytes))`, then
labelled Expand. That single structural fact (64‑byte salt = two concatenated 32‑byte values,
32‑byte IKM) collapsed the search space.

### 3.4 The solution

Searching `PRK = HMAC(A‖B, C)` over a pool of the known 32‑byte values (the 4 DH secrets, the
4 public keys, transcript hashes, zeros, protocol‑name hashes) hit on the **first** structural
family tried:

```
salt (64 bytes) = clientEphPub ‖ serverEphPub      # the two ephemeral PUBLIC keys
ikm             = ss = DH(clientStatic, serverStatic)   # the only secret input
PRK             = HMAC-SHA256(salt, ikm)                # = HKDF-Extract(salt, ss)
c2s             = HKDF-Expand(PRK, "falcon-c2s", 32)    # client -> server key
s2c             = HKDF-Expand(PRK, "falcon-s2c", 32)    # server -> client key
nonce(seq)      = 0x00000000 ‖ seq as u64 little-endian  # seq occupies bytes [4:12]
AAD             = <empty>
```

Both captured packets decrypt cleanly and reveal valid inner IPv6 headers, confirming the
recipe (the Poly1305 tag verifying is a ~2⁻¹²⁸ oracle — no false positives).

### 3.5 Security note

Only `ss` (a *static↔static* DH) is secret; it's the same for every session between a fixed
client/server pair. The per‑session ephemerals feed in only as **public** salt. That yields no
forward secrecy for the transport keys — a design weakness of the app, but exactly what makes a
compatible open server feasible.

---

## 4. Key‑derivation, in code

`crypto.go`:

```go
// PRK = HMAC-SHA256(salt=clientEphPub||serverEphPub, ikm=ss)
// c2s = HKDF-Expand(PRK, "falcon-c2s", 32); s2c = HKDF-Expand(PRK, "falcon-s2c", 32)
func deriveFalconKeys(clientEphPub, serverEphPub, ss []byte) *SessionKeys {
	salt := append(append([]byte{}, clientEphPub...), serverEphPub...)
	prk := hkdfExtract(salt, ss) // = hkdf.Extract(sha256, ikm=ss, salt) = HMAC(salt, ss)
	return &SessionKeys{
		C2S:    hkdfExpand(prk, "falcon-c2s", 32),
		S2C:    hkdfExpand(prk, "falcon-s2c", 32),
		Recipe: Recipe{Order: []string{"ss"}, SaltKind: "ephPub", NonceFmt: "le_mid4", AADFmt: "none"},
	}
}
```

- `hkdfExtract(salt, ikm)` maps to `hkdf.Extract(sha256, ikm, salt)` = `HMAC(salt, ikm)`.
- `hkdfExpand(prk, "falcon-c2s", 32)` = `HMAC(prk, "falcon-c2s"‖0x01)[:32]`.
- Nonce format `le_mid4` writes `seq` little‑endian at byte offset 4; bytes `[0:4]` and
  `[8:12]` stay zero — identical to `00000000 ‖ seq_u64_LE` for 32‑bit sequence numbers.

Regression test `falcon_kdf_test.go` asserts this recipe decrypts both packets in
`crack_dump.json` and that each plaintext is IPv6 (`version == 6`).

---

## 5. Server construction

### 5.1 Startup (`main.go`)

1. Load/generate the **server** static key (`server_key.b64`).
2. Load an optional `falcontunnel://import/...` config for tunnel MTU/DNS; **override** its
   server pubkey with ours.
3. If the config lacks a **client** static private key, generate/persist one
   (`client_key.b64`) and embed it — the app needs its own static priv to run the handshake.
4. Advertise the real public address (`-host` / `-port`) in the emitted import URL instead of
   `0.0.0.0`.
5. Open UDP listener; open TUN (unless `-no-tun`); auto‑configure the interface and NAT.

### 5.2 Handshake (`handleClientHello`)

```
ClientHello(65) ─▶ parse clientStaticPub, clientEphPub
                   generate serverEph keypair
                   compute ss = DH(serverStaticPriv, clientStaticPub)
                   keys = deriveFalconKeys(clientEphPub, serverEphPub, ss)   # no calibration
                   assign tunnel IP
                ◀─ ServerHello(0x02 ‖ serverStaticPub ‖ serverEphPub ‖ ip ‖ mtu ‖ dns…)
```

Keys are set at handshake time (`calibrated = true`), so the runtime brute‑force calibration
path is **bypassed** — it remains only as a fallback + `crack_dump.json` dumper for any future
unknown build.

### 5.3 Data path

- **Client → server** (`handleData`): `aeadOpen(C2S, seq, body)` → inner IPv6 packet → write to
  TUN (`deliverInner`).
- **Server → client** (`tunReadLoop`): read inner packet from TUN → `aeadSeal(S2C, txSeq, pkt)`
  → send `0x03 ‖ txSeq(4 BE) ‖ ct ‖ tag`.
- Both directions use the `le_mid4` nonce and empty AAD.

### 5.4 TUN + NAT (`tun_linux.go`)

- `configureTUN`: `ip addr add <cidr>`, set MTU, bring link up, enable
  `net.ipv4.ip_forward`.
- `detectWAN`: parse `ip -o route get 1.1.1.1` for the egress interface.
- `setupNAT`: idempotent `MASQUERADE` (POSTROUTING) + two `FORWARD` rules.

> ⚠️ **IPv6 egress.** Inner traffic is IPv6, but `setupNAT` currently configures **IPv4**
> MASQUERADE only. For real IPv6 internet through the tunnel you need `net.ipv6.conf.all.
> forwarding=1` and an `ip6tables` NAT/route (or the client falling back to IPv4 once the
> tunnel is up). This is the remaining end‑to‑end gap.

---

## 6. Files

| File | Role |
|------|------|
| `main.go` | UDP loop, handshake, data path, TUN read loop, flags |
| `crypto.go` | X25519, HKDF, `deriveFalconKeys` (the recovered recipe), AEAD open/seal, nonce/AAD builders, legacy calibration recipes |
| `config.go` | key load/generate, import‑URL encode/decode |
| `tun_linux.go` | `/dev/net/tun`, `configureTUN`, `detectWAN`, `setupNAT` |
| `tun_other.go` | no‑op stubs for non‑Linux builds |
| `falcon_kdf_test.go` | regression test asserting the recipe decrypts `crack_dump.json` |
| `crypto_test.go` | handshake/calibration round‑trip test |
| `crack_dump.json` | captured DH secrets + pubkeys + ciphertext (ground truth) |

Reverse‑engineering aid (outside the server dir): `re_tool.py` — `str`/`xref`/`xb`/`callers`/
`dis`/`func` over `libfalcon_android.so` via pyelftools + capstone.

---

## 7. Build & run

```bash
# cross-compile for the Linux VPS
GOOS=linux GOARCH=amd64 go build -o falcon-server-linux ./...

# run (needs root for TUN + iptables)
sudo ./falcon-server-linux \
     -host 84.32.50.8 \      # public IP advertised in the import URL
     -listen :1194 \
     -tun falcon0 \
     -subnet 10.9.0.1
```

Useful flags: `-verbose` (log every inbound packet), `-no-tun` (crypto‑only debug),
`-nat=false` (skip auto iptables), `-config <falcontunnel://import/...>` (import MTU/DNS).

On start the server prints the import URL to hand to the app (its server pubkey is replaced
with ours, and a client static key is embedded).

---

## 8. Verify

```bash
go test ./...                    # full suite
go test -run TestFalconKDF -v    # proves the recipe decrypts the real captured packets
```

Expected:

```
seq 0 OK: 76 bytes inner IPv6
seq 1 OK: 48 bytes inner IPv6
```
